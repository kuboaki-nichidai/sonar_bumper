#include "app.h"
#include "linemon.h"
#include "driver.h"

extern void line_tracer_config(void);
extern void line_tracer_run(void);
extern void line_tracer_stop(void);
