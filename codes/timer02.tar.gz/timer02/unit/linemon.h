#include "app.h"

extern void linemon_config(void);
extern bool linemon_is_online(void);
