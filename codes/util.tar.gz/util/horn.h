#ifndef MY_HORN_H_
#define MY_HORN_H_

#include "ev3api.h"

extern void horn_warning(void);
extern void horn_confirmation(void);
extern void horn_arrived(void);

#endif  // MY_HORN_H_
